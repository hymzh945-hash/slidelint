# SlideLint Pro — quickstart

SlideLint finds what breaks a deck in the room: text that overflows its box, shapes off
the canvas, overlapping text, font sprawl, placeholder copy, missing titles, images with
no alt text, slides with no notes.

## 1. Install

```bash
pip install slidelint
```

Python 3.9+. No network access needed at runtime.

## 2. Activate Pro

Put the licence file we emailed you at either:

```bash
~/slidelint-license.json
# or
~/.slidelint/license.json
```

Or point at it explicitly:

```bash
export SLIDELINT_LICENSE=/path/to/slidelint-license.json
```

Check it:

```bash
slidelint license
# Pro license · you@example.com · expires 2027-11-18
```

Verification is local (Ed25519 against a public key inside the package). Nothing calls
home, so it works on a plane and inside a client's network.

## 3. Audit a deck

```bash
slidelint audit -i board_review.pptx
```

Terminal output: score, verdict, per-check counts.

## 4. Get the report and the CSV (Pro)

```bash
slidelint audit -i board_review.pptx --report deck-review.html --csv findings.csv
```

- `deck-review.html` — self-contained, dark, one file. Send it to the deck owner.
- `findings.csv` — one row per finding: severity, check, slide, shape, detail. Drop it into
  the review tracker or a Jira import.

## 5. Learn it on a broken deck

```bash
slidelint demo -o slidelint-demo
```

Writes `demo_deck.pptx` (six slides with the mistakes people really send), audits it, and
writes `slidelint-report.html`.

## What the score means

`100 * exp(-penalty / 120)`, where penalty is the severity-weighted sum of findings, capped
per check so one noisy check cannot flatten the result.

- **85+** — ship it.
- **65–84** — an hour of fixes.
- **below 65** — will embarrass you live.

## Checks included

| Check | Severity |
|---|---|
| placeholder_text — Lorem ipsum, TBD, click-to-add left in | high |
| text_overflow — more characters than the box holds | high |
| off_slide — shape outside the canvas | high |
| overlapping_text — two text boxes on each other | medium |
| font_outlier — a font used once in the whole deck | medium |
| font_size_sprawl — more than four sizes on a slide | medium |
| tiny_text — under 12pt | medium |
| missing_title — slide with no title | medium |
| duplicate_title — same title twice | low |
| reading_load — over 90 words on a slide | low |
| missing_alt_text — alt text empty or a file name | medium |
| no_speaker_notes — nobody can present it for you | low |
| unterminated_sentence — long sentence, no full stop | low |

## Limits, stated plainly

- It reads the `.pptx` XML, it does not render. It cannot see font substitution that only
  happens on the presenting machine, and it estimates overflow from box size and font size
  rather than measuring real glyph widths. Treat the overflow check as a strong hint, not a
  pixel verdict.
- Only `.pptx` / `.pptm`. `.ppt` is out of scope.
- Charts, SmartArt and grouped shapes are not scored individually.

## Support

Reply to the receipt email. Include the deck if you can — we do not redistribute it.
